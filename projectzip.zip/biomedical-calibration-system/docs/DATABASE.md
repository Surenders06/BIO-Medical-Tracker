# Database Design: Biomedical Device Calibration and Maintenance Management System

## 1. Overview
* **Database Engine**: MongoDB (Document-oriented NoSQL)
* **Object Data Modeling (ODM)**: Mongoose (v8+)
* **Database Name**: `biomedical_calibration_db`
* **Character Encoding**: UTF-8

The database schema models the lifecycle of biomedical hospital assets, tracking routine calibration logs, maintenance requests, and user credentials with role-based access.

---

## 2. Collections & Schema Specifications

### 2.1. `users` Collection (Model: `User`)
Stores system users across administrative, technical, and hospital staff tiers.

| Field | Type | Required | Constraints / Default | Description |
|---|---|---|---|---|
| `_id` | ObjectId | Auto | Unique identifier | Primary Key |
| `name` | String | Yes | Trimmed | Full name of the user |
| `email` | String | Yes | Unique, Lowercase, Regex validated | Official hospital email address |
| `password` | String | Yes | Min length 6, Hashed via bcryptjs | Securely hashed password (hidden by default) |
| `role` | String | Yes | Enum: `['Admin', 'Technician', 'Staff']`, Default: `'Staff'` | Access control tier |
| `department` | String | Yes | Default: `'Biomedical Engineering'` | Department or clinical ward |
| `createdAt` | Date | Auto | Default: `Date.now` | Account creation timestamp |
| `updatedAt` | Date | Auto | Default: `Date.now` | Account update timestamp |

**Mongoose Hooks & Methods**:
* `pre('save')`: Hashes `password` using `bcrypt.genSalt(10)` if modified.
* `comparePassword(candidatePassword)`: Compares plaintext input with hashed password via `bcrypt.compare`.

---

### 2.2. `equipment` Collection (Model: `Equipment`)
Maintains the master inventory of biomedical devices in the hospital.

| Field | Type | Required | Constraints / Default | Description |
|---|---|---|---|---|
| `_id` | ObjectId | Auto | Unique identifier | Primary Key |
| `equipmentId` | String | Yes | Unique, Uppercase, Trimmed (e.g. `BMD-ECG-101`) | Asset inventory tag |
| `name` | String | Yes | Trimmed | Clinical device name |
| `category` | String | Yes | Enum: `['Diagnostic', 'Life Support', 'Monitoring', 'Laboratory', 'Therapeutic', 'Surgical']` | Clinical classification |
| `manufacturer` | String | Yes | Trimmed (e.g. `GE Healthcare`, `Philips`) | OEM equipment maker |
| `model` | String | Yes | Trimmed (e.g. `MAC 2000`, `Evita V300`) | Model number/name |
| `serialNumber` | String | No | Trimmed, Default: `'N/A'` | Manufacturer serial number |
| `location.department` | String | Yes | Trimmed (e.g. `Cardiology ICU`) | Hospital clinical ward |
| `location.roomNumber` | String | No | Default: `'General'` | Room or bed bay |
| `location.building` | String | No | Default: `'Main Block'` | Hospital wing or block |
| `purchaseDate` | Date | No | Default: `Date.now` | Procurement date |
| `purchaseCost` | Number | No | Min: `0`, Default: `0` | Asset purchase value |
| `status` | String | Yes | Enum: `['Operational', 'Maintenance Required', 'Calibration Due', 'Out of Service']`, Default: `'Operational'` | Current device status |
| `calibrationFrequencyMonths` | Number | Yes | Min: `1`, Default: `6` | Calibration interval in months |
| `lastCalibrationDate` | Date | No | Default: `null` | Most recent calibration timestamp |
| `nextCalibrationDate` | Date | No | Default: `null` | Upcoming calibration deadline |
| `createdBy` | ObjectId | Yes | Ref: `User` | User who registered the device |
| `createdAt` | Date | Auto | Default: `Date.now` | Record creation timestamp |
| `updatedAt` | Date | Auto | Default: `Date.now` | Record update timestamp |

---

### 2.3. `calibrations` Collection (Model: `Calibration`)
Stores individual calibration events performed against standard reference instruments.

| Field | Type | Required | Constraints / Default | Description |
|---|---|---|---|---|
| `_id` | ObjectId | Auto | Unique identifier | Primary Key |
| `calibrationId` | String | Yes | Unique, Uppercase, Trimmed (e.g. `CAL-2026-001`) | Calibration certificate number |
| `equipment` | ObjectId | Yes | Ref: `Equipment` | Target biomedical device |
| `calibrationDate` | Date | Yes | Default: `Date.now` | Date calibration was executed |
| `nextCalibrationDate` | Date | Yes | Valid Date | Next calibration target date |
| `calibratedBy` | ObjectId | Yes | Ref: `User` | Technician who executed the test |
| `technicianName` | String | Yes | Trimmed | Technician display name |
| `calibrationStandard` | String | Yes | Trimmed | Standard test instrument used (e.g. `Fluke ProSim 8`) |
| `result` | String | Yes | Enum: `['Passed', 'Passed with Adjustment', 'Failed', 'Needs Attention']` | Test outcome |
| `parametersChecked` | Array | No | Subdocument array (see below) | List of tested parameters |
| `remarks` | String | No | Trimmed | Observations and adjustments |
| `createdAt` | Date | Auto | Default: `Date.now` | Log creation timestamp |

**Subdocument: `parametersChecked` Array Structure**:
```json
[
  {
    "parameter": "Heart Rate Accuracy (60 BPM)",
    "referenceValue": "60 BPM",
    "measuredValue": "60.1 BPM",
    "status": "Pass"
  }
]
```

---

### 2.4. `maintenances` Collection (Model: `Maintenance`)
Tracks corrective, preventive, and breakdown maintenance work orders.

| Field | Type | Required | Constraints / Default | Description |
|---|---|---|---|---|
| `_id` | ObjectId | Auto | Unique identifier | Primary Key |
| `workOrderId` | String | Yes | Unique, Uppercase (e.g. `WO-2026-001`) | Maintenance ticket number |
| `equipment` | ObjectId | Yes | Ref: `Equipment` | Target biomedical device |
| `maintenanceType` | String | Yes | Enum: `['Preventive', 'Corrective', 'Emergency Breakdown']` | Nature of maintenance |
| `issueDescription` | String | Yes | Trimmed | Description of defect or breakdown |
| `reportedDate` | Date | Yes | Default: `Date.now` | Ticket creation date |
| `status` | String | Yes | Enum: `['Reported', 'Assigned', 'In Progress', 'Resolved', 'Closed']`, Default: `'Reported'` | Ticket lifecycle state |
| `priority` | String | Yes | Enum: `['Low', 'Medium', 'High', 'Critical']`, Default: `'Medium'` | Severity level |
| `actionTaken` | String | No | Default: `'Pending inspection'` | Technical work performed |
| `reportedBy` | ObjectId | No | Ref: `User` | User who logged the fault |
| `assignedTo` | ObjectId | No | Ref: `User` | Technician handling the repair |
| `createdAt` | Date | Auto | Default: `Date.now` | Timestamp |
| `updatedAt` | Date | Auto | Default: `Date.now` | Timestamp |

---

## 3. Entity Relationship Diagram (ERD)

```
+------------------+         1:N          +------------------+
|      users       |--------------------->|    equipment     |
|------------------|                      |------------------|
| _id (PK)         |                      | _id (PK)         |
| name             |                      | equipmentId (UQ) |
| email (UQ)       |                      | name             |
| password         |                      | category         |
| role             |                      | createdBy (FK)   |
| department       |                      +------------------+
+------------------+                               │
         │                                         │
         │ 1:N                                     │ 1:N
         ▼                                         ▼
+------------------+         N:1          +------------------+
|   calibrations   |<---------------------|   maintenances   |
|------------------|                      |------------------|
| _id (PK)         |                      | _id (PK)         |
| calibrationId(UQ)|                      | workOrderId (UQ) |
| equipment (FK)   |                      | equipment (FK)   |
| calibratedBy(FK) |                      | status           |
| calibrationDate  |                      | priority         |
| result           |                      +------------------+
+------------------+
```

---

## 4. Status Rules & Automated Synchronization Logic

### 4.1. Date-Derived Calibration Status Alerts
Status alerts are dynamically evaluated by comparing the device's `nextCalibrationDate` with the current system date (`new Date()`):

1. **Overdue / Calibration Due**:
   * Condition: `nextCalibrationDate <= currentDate`
   * Alert Level: `CRITICAL (RED)`
   * System Action: Equipment marked as `Calibration Due` or `Overdue`. Immediate recalibration required before clinical use.

2. **Upcoming Due (Within 15 Days)**:
   * Condition: `nextCalibrationDate > currentDate` AND `nextCalibrationDate <= (currentDate + 15 days)`
   * Alert Level: `WARNING (AMBER)`
   * System Action: Displayed on Dashboard Upcoming Calibration List for scheduling.

3. **Compliant / Operational**:
   * Condition: `nextCalibrationDate > (currentDate + 15 days)`
   * Alert Level: `NORMAL (GREEN)`
   * System Action: Equipment is verified compliant and operational.

---

### 4.2. Calibration-to-Equipment Synchronization Rules
Whenever a technician submits a new calibration log for an equipment item:

1. **Test Result: `Passed` or `Passed with Adjustment`**:
   * `Equipment.lastCalibrationDate` = `Calibration.calibrationDate`
   * `Equipment.nextCalibrationDate` = `Calibration.nextCalibrationDate` (calculated as `calibrationDate + calibrationFrequencyMonths`)
   * `Equipment.status` = `'Operational'`

2. **Test Result: `Failed`**:
   * `Equipment.lastCalibrationDate` = `Calibration.calibrationDate`
   * `Equipment.status` = `'Out of Service'`
   * Equipment cannot be used in patient care until repaired and recalibrated.

3. **Test Result: `Needs Attention`**:
   * `Equipment.lastCalibrationDate` = `Calibration.calibrationDate`
   * `Equipment.status` = `'Maintenance Required'`
   * Triggers or recommends creation of a Maintenance work order.

---

## 5. Phase 1 Implementation Verification: Mongoose Models & Index Registry

The models have been implemented in `server/models/` with strict schema validation, references, and compound indexes:

| Model File | Collection | References | Indexes Configured | Implementation State |
|---|---|---|---|:---:|
| [`server/models/User.js`](file:///C:/Users/Srinivasan%20M/.gemini/antigravity-ide/scratch/Biomedical-Calibration-System/server/models/User.js) | `users` | None | `email` (Unique), `role` | **IMPLEMENTED** |
| [`server/models/Equipment.js`](file:///C:/Users/Srinivasan%20M/.gemini/antigravity-ide/scratch/Biomedical-Calibration-System/server/models/Equipment.js) | `equipment` | `createdBy` -> `User` | `equipmentId` (Unique), `{ category: 1, status: 1 }`, `nextCalibrationDate`, text index on `{ name, manufacturer, model }` | **IMPLEMENTED** |
| [`server/models/Calibration.js`](file:///C:/Users/Srinivasan%20M/.gemini/antigravity-ide/scratch/Biomedical-Calibration-System/server/models/Calibration.js) | `calibrations` | `equipment` -> `Equipment`, `calibratedBy` -> `User` | `calibrationId` (Unique), `equipment`, `calibrationDate`, `nextCalibrationDate`, `{ equipment: 1, calibrationDate: -1 }` | **IMPLEMENTED** |
| [`server/models/Maintenance.js`](file:///C:/Users/Srinivasan%20M/.gemini/antigravity-ide/scratch/Biomedical-Calibration-System/server/models/Maintenance.js) | `maintenances` | `equipment` -> `Equipment`, `reportedBy` -> `User`, `assignedTo` -> `User` | `workOrderId` (Unique), `equipment`, `status`, `priority`, `{ equipment: 1, status: 1 }` | **IMPLEMENTED** |

