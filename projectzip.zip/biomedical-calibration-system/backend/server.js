const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const connectDB = require('./config/db');

// Load environment variables
dotenv.config();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logger for development / review debugging
app.use((req, res, next) => {
  console.log(`[API Request] ${req.method} ${req.originalUrl}`);
  next();
});

// Mount Routes
const authRoutes = require('./routes/authRoutes');
const equipmentRoutes = require('./routes/equipmentRoutes');
const calibrationRoutes = require('./routes/calibrationRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');

app.use('/api/auth', authRoutes);
app.use('/api/equipment', equipmentRoutes);
app.use('/api/calibrations', calibrationRoutes);
app.use('/api/dashboard', dashboardRoutes);

// System Status / Health check endpoint
app.get('/api/status', (req, res) => {
  res.status(200).json({
    status: 'Operational',
    system: 'Biomedical Device Calibration and Maintenance Management System',
    developmentPhase: 'Approximately 50% Prototype (Mid-Development College Review Version)',
    supportedRoles: ['Admin', 'Technician', 'Staff'],
    activeModules: [
      'Authentication & JWT Security',
      'Biomedical Equipment Management (CRUD)',
      'Calibration Records & Parameter Logs',
      'Real Database Metrics Dashboard'
    ],
    plannedModules: [
      'Advanced Maintenance Work Orders & Spare Parts',
      'Regulatory Compliance Audit PDF Reports',
      'Automated Calibration Reminder Alerts',
      'QR Code Asset Tagging'
    ]
  });
});

// Root route
app.get('/', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Biomedical Calibration API</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 40px; }
          .card { background: #1e293b; border-radius: 12px; padding: 24px; max-width: 600px; margin: 0 auto; box-shadow: 0 10px 25px rgba(0,0,0,0.3); border: 1px solid #334155; }
          h2 { color: #38bdf8; margin-top: 0; }
          .badge { display: inline-block; background: #0284c7; color: white; padding: 4px 10px; border-radius: 999px; font-size: 13px; font-weight: 600; }
          code { background: #0f172a; padding: 2px 6px; border-radius: 4px; color: #a5f3fc; }
        </style>
      </head>
      <body>
        <div class="card">
          <h2>Biomedical Calibration API</h2>
          <p><span class="badge">Development Stage: Approximately 50%</span></p>
          <p>College Project Review Prototype is running.</p>
          <p>API Base URL: <code>/api</code></p>
          <p>Health check: <a style="color:#38bdf8" href="/api/status">/api/status</a></p>
        </div>
      </body>
    </html>
  `);
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('[Unhandled Error]:', err.stack);

  // Mongoose duplicate key error
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    return res.status(400).json({
      success: false,
      message: `A record with that ${field} already exists.`
    });
  }

  // Mongoose CastError (invalid ObjectId)
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: `Resource not found with format: ${err.value}`
    });
  }

  // Mongoose validation error
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map((val) => val.message);
    return res.status(400).json({
      success: false,
      message: messages.join(', ')
    });
  }

  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

const PORT = process.env.PORT || 5000;

// Initialize Server & auto-seed if needed
const startServer = async () => {
  const isConnected = await connectDB();

  if (isConnected) {
    // Check if initial users exist; if not, trigger seed
    try {
      const User = require('./models/User');
      const count = await User.countDocuments();
      if (count === 0) {
        console.log('[Auto-Seed] Database is fresh. Seeding initial biomedical test data...');
        const seedDatabase = require('./seed/seedData');
        await seedDatabase();
      }
    } catch (seedErr) {
      console.error('[Auto-Seed Warning]:', seedErr.message);
    }
  }

  app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(` Biomedical Device Calibration & Maintenance System`);
    console.log(` Express Server active on: http://localhost:${PORT}`);
    console.log(` Mode: ${process.env.NODE_ENV || 'development'}`);
    console.log(` Stage: Approximately 50% Review Prototype`);
    console.log(`====================================================`);
  });
};

startServer();

module.exports = app;
