const express = require('express');
const router = express.Router();
const {
  getEquipment,
  getEquipmentById,
  createEquipment,
  updateEquipment,
  deleteEquipment
} = require('../controllers/equipmentController');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');

// All equipment routes require authentication
router.use(protect);

// View equipment list (Admin, Technician, Staff)
router.get('/', getEquipment);

// View equipment details (Admin, Technician, Staff)
router.get('/:id', getEquipmentById);

// Create equipment (Admin, Technician)
router.post('/', authorize('Admin', 'Technician'), createEquipment);

// Edit equipment (Admin, Technician)
router.put('/:id', authorize('Admin', 'Technician'), updateEquipment);

// Delete equipment (Admin only)
router.delete('/:id', authorize('Admin'), deleteEquipment);

module.exports = router;
