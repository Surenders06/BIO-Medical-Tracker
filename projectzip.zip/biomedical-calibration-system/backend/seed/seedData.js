const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../.env') });

const User = require('../models/User');
const Equipment = require('../models/Equipment');
const Calibration = require('../models/Calibration');
const Maintenance = require('../models/Maintenance');

const seedDatabase = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/biomedical_calibration_db';
    console.log(`[Seed Script] Connecting to MongoDB at: ${mongoUri}`);
    await mongoose.connect(mongoUri);

    console.log('[Seed Script] Connected. Resetting collections...');
    await User.deleteMany({});
    await Equipment.deleteMany({});
    await Calibration.deleteMany({});
    await Maintenance.deleteMany({});

    console.log('[Seed Script] Creating test users across 3 roles...');
    // Note: User model has pre('save') hook that hashes passwords
    const adminUser = new User({
      name: 'Dr. Rajesh Sharma (Head BME)',
      email: 'admin@biomed.hospital.org',
      password: 'Admin@123',
      role: 'Admin',
      department: 'Biomedical Engineering Dept'
    });
    await adminUser.save();

    const techUser = new User({
      name: 'Priya Raman (Sr. Biomedical Tech)',
      email: 'tech.priya@biomed.hospital.org',
      password: 'Tech@123',
      role: 'Technician',
      department: 'Clinical Calibration Services'
    });
    await techUser.save();

    const staffUser = new User({
      name: 'Sister Mary Joseph (ICU In-Charge)',
      email: 'staff.mary@biomed.hospital.org',
      password: 'Staff@123',
      role: 'Staff',
      department: 'Critical Care ICU'
    });
    await staffUser.save();

    console.log('[Seed Script] Seeding 8 genuine biomedical devices...');
    const now = new Date();

    const pastDate = (daysAgo) => {
      const d = new Date(now);
      d.setDate(d.getDate() - daysAgo);
      return d;
    };

    const futureDate = (daysAhead) => {
      const d = new Date(now);
      d.setDate(d.getDate() + daysAhead);
      return d;
    };

    const equipmentList = [
      {
        equipmentId: 'BMD-ECG-101',
        name: '12-Lead Diagnostic ECG Machine',
        category: 'Diagnostic',
        manufacturer: 'GE Healthcare',
        model: 'MAC 2000',
        serialNumber: 'GE-MAC-98231',
        location: { department: 'Cardiology ICU', roomNumber: 'ICU-Bed 04', building: 'Block A - Critical Care' },
        purchaseDate: pastDate(720),
        purchaseCost: 450000,
        status: 'Operational',
        calibrationFrequencyMonths: 6,
        lastCalibrationDate: pastDate(45),
        nextCalibrationDate: futureDate(135),
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-MON-204',
        name: 'Multiparameter Patient Monitor',
        category: 'Monitoring',
        manufacturer: 'Philips Healthcare',
        model: 'IntelliVue MX700',
        serialNumber: 'PH-MX7-44019',
        location: { department: 'Emergency Ward', roomNumber: 'Trauma Bay 2', building: 'Emergency Complex' },
        purchaseDate: pastDate(500),
        purchaseCost: 620000,
        status: 'Calibration Due',
        calibrationFrequencyMonths: 6,
        lastCalibrationDate: pastDate(185),
        nextCalibrationDate: pastDate(5), // Overdue by 5 days
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-INF-310',
        name: 'Volumetric Infusion Pump',
        category: 'Therapeutic',
        manufacturer: 'B. Braun',
        model: 'Infusomat Space',
        serialNumber: 'BB-ISP-77182',
        location: { department: 'Pediatric ICU', roomNumber: 'NICU Incubator 3', building: 'Block C - Mother & Child' },
        purchaseDate: pastDate(400),
        purchaseCost: 110000,
        status: 'Operational',
        calibrationFrequencyMonths: 6,
        lastCalibrationDate: pastDate(30),
        nextCalibrationDate: futureDate(150),
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-VEN-402',
        name: 'Critical Care ICU Ventilator',
        category: 'Life Support',
        manufacturer: 'Dräger',
        model: 'Evita V300',
        serialNumber: 'DRG-EV3-50912',
        location: { department: 'Critical Care ICU', roomNumber: 'Isolation Room 1', building: 'Block A - Critical Care' },
        purchaseDate: pastDate(900),
        purchaseCost: 1850000,
        status: 'Operational',
        calibrationFrequencyMonths: 3,
        lastCalibrationDate: pastDate(20),
        nextCalibrationDate: futureDate(70),
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-DEF-501',
        name: 'Biphasic Defibrillator & Monitor',
        category: 'Life Support',
        manufacturer: 'ZOLL Medical',
        model: 'R Series ALS',
        serialNumber: 'ZL-RS-33810',
        location: { department: 'Operation Theater', roomNumber: 'OT Suite 3', building: 'Surgical Wing' },
        purchaseDate: pastDate(620),
        purchaseCost: 950000,
        status: 'Maintenance Required',
        calibrationFrequencyMonths: 6,
        lastCalibrationDate: pastDate(190),
        nextCalibrationDate: pastDate(10),
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-ESU-603',
        name: 'High-Frequency Electrosurgical Unit',
        category: 'Surgical',
        manufacturer: 'Medtronic Covidien',
        model: 'Force FX-C',
        serialNumber: 'CV-FXC-19022',
        location: { department: 'General Surgery', roomNumber: 'OT Suite 1', building: 'Surgical Wing' },
        purchaseDate: pastDate(800),
        purchaseCost: 820000,
        status: 'Operational',
        calibrationFrequencyMonths: 12,
        lastCalibrationDate: pastDate(90),
        nextCalibrationDate: futureDate(275),
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-LAB-708',
        name: 'Automated Blood Gas Analyzer',
        category: 'Laboratory',
        manufacturer: 'Radiometer',
        model: 'ABL90 FLEX PLUS',
        serialNumber: 'RAD-ABL-61200',
        location: { department: 'Clinical Pathology Lab', roomNumber: 'Lab Station 4', building: 'Diagnostic Wing' },
        purchaseDate: pastDate(300),
        purchaseCost: 1250000,
        status: 'Operational',
        calibrationFrequencyMonths: 3,
        lastCalibrationDate: pastDate(15),
        nextCalibrationDate: futureDate(75),
        createdBy: adminUser._id
      },
      {
        equipmentId: 'BMD-OXI-805',
        name: 'Continuous Pulse Oximeter Station',
        category: 'Monitoring',
        manufacturer: 'Masimo',
        model: 'Rad-97 Pulse CO-Oximeter',
        serialNumber: 'MAS-R97-20411',
        location: { department: 'General Medical Ward', roomNumber: 'Room 214', building: 'Block B - Inpatient' },
        purchaseDate: pastDate(450),
        purchaseCost: 195000,
        status: 'Out of Service',
        calibrationFrequencyMonths: 6,
        lastCalibrationDate: pastDate(210),
        nextCalibrationDate: pastDate(30),
        createdBy: adminUser._id
      }
    ];

    const savedEquipment = await Equipment.insertMany(equipmentList);
    console.log(`[Seed Script] Successfully saved ${savedEquipment.length} equipment items.`);

    console.log('[Seed Script] Seeding realistic calibration records...');
    const calibrationLogs = [
      {
        calibrationId: 'CAL-2026-001',
        equipment: savedEquipment[0]._id, // ECG
        calibrationDate: pastDate(45),
        nextCalibrationDate: futureDate(135),
        calibratedBy: techUser._id,
        technicianName: techUser.name,
        calibrationStandard: 'Fluke Biomedical ProSim 8 Vital Signs Simulator (Cal S/N: FLK-8812)',
        result: 'Passed',
        parametersChecked: [
          { parameter: 'Heart Rate Accuracy (60 BPM)', referenceValue: '60 BPM', measuredValue: '60 BPM', status: 'Pass' },
          { parameter: 'Heart Rate Accuracy (120 BPM)', referenceValue: '120 BPM', measuredValue: '120.1 BPM', status: 'Pass' },
          { parameter: 'ECG Amplitude (1.0 mV)', referenceValue: '1.0 mV', measuredValue: '0.99 mV', status: 'Pass' },
          { parameter: 'Paper Speed (25 mm/s)', referenceValue: '25.0 mm/s', measuredValue: '25.0 mm/s', status: 'Pass' }
        ],
        remarks: 'ECG baseline filter and lead selector within acceptable clinical tolerance (+-1%). Calibration certificate generated.'
      },
      {
        calibrationId: 'CAL-2026-002',
        equipment: savedEquipment[2]._id, // Infusion Pump
        calibrationDate: pastDate(30),
        nextCalibrationDate: futureDate(150),
        calibratedBy: techUser._id,
        technicianName: techUser.name,
        calibrationStandard: 'Rigel Multi-Flo Infusion Pump Analyzer',
        result: 'Passed',
        parametersChecked: [
          { parameter: 'Flow Rate (10 ml/hr)', referenceValue: '10.0 ml/hr', measuredValue: '9.96 ml/hr', status: 'Pass' },
          { parameter: 'Flow Rate (100 ml/hr)', referenceValue: '100.0 ml/hr', measuredValue: '100.2 ml/hr', status: 'Pass' },
          { parameter: 'Occlusion Pressure Limit', referenceValue: '10.0 psi', measuredValue: '9.8 psi', status: 'Pass' }
        ],
        remarks: 'Occlusion pressure threshold and flow accuracy verified successfully.'
      },
      {
        calibrationId: 'CAL-2026-003',
        equipment: savedEquipment[3]._id, // Ventilator
        calibrationDate: pastDate(20),
        nextCalibrationDate: futureDate(70),
        calibratedBy: techUser._id,
        technicianName: techUser.name,
        calibrationStandard: 'TSI Certifier Pro Ventilator Test System',
        result: 'Passed with Adjustment',
        parametersChecked: [
          { parameter: 'FiO2 Concentration (21%)', referenceValue: '21.0 %', measuredValue: '21.1 %', status: 'Pass' },
          { parameter: 'FiO2 Concentration (100%)', referenceValue: '100.0 %', measuredValue: '97.8 %', status: 'Adjusted' },
          { parameter: 'Tidal Volume (500 ml)', referenceValue: '500 ml', measuredValue: '498 ml', status: 'Pass' },
          { parameter: 'PEEP Pressure (10 cmH2O)', referenceValue: '10.0 cmH2O', measuredValue: '10.1 cmH2O', status: 'Pass' }
        ],
        remarks: 'O2 cell calibrated and re-zeroed. All ventilation parameters verified safe for critical patient use.'
      },
      {
        calibrationId: 'CAL-2026-004',
        equipment: savedEquipment[4]._id, // Defibrillator
        calibrationDate: pastDate(190),
        nextCalibrationDate: pastDate(10),
        calibratedBy: techUser._id,
        technicianName: techUser.name,
        calibrationStandard: 'Fluke Biomedical Impulse 7000DP Defibrillator Analyzer',
        result: 'Needs Attention',
        parametersChecked: [
          { parameter: 'Energy Output (50 Joules)', referenceValue: '50 J', measuredValue: '48.2 J', status: 'Pass' },
          { parameter: 'Energy Output (200 Joules)', referenceValue: '200 J', measuredValue: '184.0 J', status: 'Fail' },
          { parameter: 'Sync Delay Time', referenceValue: '< 60 ms', measuredValue: '54 ms', status: 'Pass' }
        ],
        remarks: 'High energy discharge delivered below 10% tolerance limit at 200J. Battery cell replacement recommended. Work order flagged.'
      },
      {
        calibrationId: 'CAL-2026-005',
        equipment: savedEquipment[5]._id, // Electrosurgical Unit
        calibrationDate: pastDate(90),
        nextCalibrationDate: futureDate(275),
        calibratedBy: techUser._id,
        technicianName: techUser.name,
        calibrationStandard: 'Rigel Uni-Therm Electrosurgical Analyzer',
        result: 'Passed',
        parametersChecked: [
          { parameter: 'Pure Cut Power (300W @ 300 ohm)', referenceValue: '300 W', measuredValue: '298 W', status: 'Pass' },
          { parameter: 'Coagulation Power (120W)', referenceValue: '120 W', measuredValue: '119 W', status: 'Pass' },
          { parameter: 'HF Leakage Current', referenceValue: '< 150 mA', measuredValue: '82 mA', status: 'Pass' }
        ],
        remarks: 'RF power leakage and contact quality monitor (CQM) verified safe for OT surgery.'
      },
      {
        calibrationId: 'CAL-2026-006',
        equipment: savedEquipment[7]._id, // Pulse Oximeter (Out of Service)
        calibrationDate: pastDate(210),
        nextCalibrationDate: pastDate(30),
        calibratedBy: techUser._id,
        technicianName: techUser.name,
        calibrationStandard: 'Fluke Index 2 SpO2 Simulator',
        result: 'Failed',
        parametersChecked: [
          { parameter: 'SpO2 Saturation (100%)', referenceValue: '100 %', measuredValue: '91 %', status: 'Fail' },
          { parameter: 'SpO2 Saturation (80%)', referenceValue: '80 %', measuredValue: '72 %', status: 'Fail' },
          { parameter: 'Pulse Rate (60 BPM)', referenceValue: '60 BPM', measuredValue: 'Error', status: 'Fail' }
        ],
        remarks: 'Photodiode pre-amplifier board failure detected. Device removed from service pending sensor module replacement.'
      }
    ];

    await Calibration.insertMany(calibrationLogs);
    console.log(`[Seed Script] Successfully saved ${calibrationLogs.length} calibration records.`);

    // Seed baseline maintenance record (demonstrating Phase 2 readiness)
    const maintenanceEntry = new Maintenance({
      workOrderId: 'WO-2026-001',
      equipment: savedEquipment[4]._id,
      maintenanceType: 'Corrective',
      issueDescription: 'Energy discharge drop observed during calibration check (CAL-2026-004). Capacitor bank check needed.',
      status: 'Reported',
      priority: 'High',
      actionTaken: 'Assigned to biomedical vendor service engineer for paddle recalibration.'
    });
    await maintenanceEntry.save();
    console.log('[Seed Script] Seeded baseline maintenance work order for Phase 2 foundation.');

    console.log('----------------------------------------------------');
    console.log('Database Seeding Completed Successfully!');
    console.log('Test Login Credentials:');
    console.log('1. Admin:      admin@biomed.hospital.org      / Admin@123');
    console.log('2. Technician: tech.priya@biomed.hospital.org / Tech@123');
    console.log('3. Staff:      staff.mary@biomed.hospital.org / Staff@123');
    console.log('----------------------------------------------------');

    if (process.argv[1].includes('seedData.js')) {
      process.exit(0);
    }
  } catch (error) {
    console.error('[Seed Script Error]:', error);
    if (process.argv[1].includes('seedData.js')) {
      process.exit(1);
    }
  }
};

if (require.main === module) {
  seedDatabase();
}

module.exports = seedDatabase;
