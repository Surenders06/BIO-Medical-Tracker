const Equipment = require('../models/Equipment');
const Calibration = require('../models/Calibration');

/**
 * @desc    Get all biomedical equipment with filtering and search
 * @route   GET /api/equipment
 * @access  Private (Admin, Technician, Staff)
 */
const getEquipment = async (req, res) => {
  try {
    const { search, category, status } = req.query;

    const query = {};

    // Search query across name, equipmentId, manufacturer, or model
    if (search && search.trim() !== '') {
      const searchRegex = new RegExp(search.trim(), 'i');
      query.$or = [
        { name: searchRegex },
        { equipmentId: searchRegex },
        { manufacturer: searchRegex },
        { model: searchRegex }
      ];
    }

    // Filter by category
    if (category && category !== 'All') {
      query.category = category;
    }

    // Filter by status
    if (status && status !== 'All') {
      query.status = status;
    }

    const equipmentList = await Equipment.find(query)
      .populate('createdBy', 'name email role')
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      count: equipmentList.length,
      data: equipmentList
    });
  } catch (error) {
    console.error('[Get Equipment Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve equipment list',
      error: error.message
    });
  }
};

/**
 * @desc    Get single equipment by ID (with calibration history)
 * @route   GET /api/equipment/:id
 * @access  Private (Admin, Technician, Staff)
 */
const getEquipmentById = async (req, res) => {
  try {
    const equipment = await Equipment.findById(req.params.id).populate(
      'createdBy',
      'name email role'
    );

    if (!equipment) {
      return res.status(404).json({
        success: false,
        message: 'Equipment not found with the specified ID'
      });
    }

    // Retrieve calibration logs for this device
    const calibrations = await Calibration.find({ equipment: equipment._id })
      .sort({ calibrationDate: -1 });

    return res.status(200).json({
      success: true,
      data: {
        ...equipment.toObject(),
        calibrations
      }
    });
  } catch (error) {
    console.error('[Get Equipment By ID Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch equipment details',
      error: error.message
    });
  }
};

/**
 * @desc    Create new biomedical equipment
 * @route   POST /api/equipment
 * @access  Private (Admin, Technician)
 */
const createEquipment = async (req, res) => {
  try {
    const {
      equipmentId,
      name,
      category,
      manufacturer,
      model,
      serialNumber,
      location,
      purchaseDate,
      purchaseCost,
      status,
      calibrationFrequencyMonths,
      lastCalibrationDate
    } = req.body;

    if (!equipmentId || !name || !category || !manufacturer || !model) {
      return res.status(400).json({
        success: false,
        message: 'Please provide all mandatory equipment fields (ID, Name, Category, Manufacturer, Model).'
      });
    }

    // Check for duplicate ID
    const existing = await Equipment.findOne({ equipmentId: equipmentId.toUpperCase().trim() });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: `An equipment with ID '${equipmentId.toUpperCase().trim()}' already exists in the system.`
      });
    }

    // Compute next calibration date if lastCalibrationDate and frequency are provided
    let computedNextCal = null;
    const freq = Number(calibrationFrequencyMonths) || 6;
    if (lastCalibrationDate) {
      const d = new Date(lastCalibrationDate);
      d.setMonth(d.getMonth() + freq);
      computedNextCal = d;
    } else {
      // Default to frequency months from now
      const d = new Date();
      d.setMonth(d.getMonth() + freq);
      computedNextCal = d;
    }

    const newEquipment = await Equipment.create({
      equipmentId: equipmentId.toUpperCase().trim(),
      name: name.trim(),
      category,
      manufacturer: manufacturer.trim(),
      model: model.trim(),
      serialNumber: serialNumber ? serialNumber.trim() : 'N/A',
      location: {
        department: (location && location.department) || 'General Biomedical',
        roomNumber: (location && location.roomNumber) || '101',
        building: (location && location.building) || 'Main Block'
      },
      purchaseDate: purchaseDate || Date.now(),
      purchaseCost: Number(purchaseCost) || 0,
      status: status || 'Operational',
      calibrationFrequencyMonths: freq,
      lastCalibrationDate: lastCalibrationDate || null,
      nextCalibrationDate: computedNextCal,
      createdBy: req.user._id
    });

    return res.status(201).json({
      success: true,
      message: 'Equipment registered successfully',
      data: newEquipment
    });
  } catch (error) {
    console.error('[Create Equipment Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create equipment record',
      error: error.message
    });
  }
};

/**
 * @desc    Update existing equipment
 * @route   PUT /api/equipment/:id
 * @access  Private (Admin, Technician)
 */
const updateEquipment = async (req, res) => {
  try {
    const equipment = await Equipment.findById(req.params.id);

    if (!equipment) {
      return res.status(404).json({
        success: false,
        message: 'Equipment record not found for update'
      });
    }

    // If ID is being updated, check for collision
    if (req.body.equipmentId && req.body.equipmentId !== equipment.equipmentId) {
      const dup = await Equipment.findOne({ equipmentId: req.body.equipmentId.toUpperCase().trim() });
      if (dup) {
        return res.status(400).json({
          success: false,
          message: `Equipment ID '${req.body.equipmentId}' is already assigned to another device.`
        });
      }
    }

    const updatedData = { ...req.body };
    if (updatedData.equipmentId) {
      updatedData.equipmentId = updatedData.equipmentId.toUpperCase().trim();
    }

    const updatedEquipment = await Equipment.findByIdAndUpdate(
      req.params.id,
      updatedData,
      { new: true, runValidators: true }
    );

    return res.status(200).json({
      success: true,
      message: 'Equipment record updated successfully',
      data: updatedEquipment
    });
  } catch (error) {
    console.error('[Update Equipment Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update equipment record',
      error: error.message
    });
  }
};

/**
 * @desc    Delete equipment
 * @route   DELETE /api/equipment/:id
 * @access  Private (Admin only)
 */
const deleteEquipment = async (req, res) => {
  try {
    const equipment = await Equipment.findById(req.params.id);

    if (!equipment) {
      return res.status(404).json({
        success: false,
        message: 'Equipment not found for deletion'
      });
    }

    // Delete associated calibration logs as well
    await Calibration.deleteMany({ equipment: equipment._id });

    await equipment.deleteOne();

    return res.status(200).json({
      success: true,
      message: `Equipment '${equipment.name}' (${equipment.equipmentId}) and its associated calibration records have been removed.`
    });
  } catch (error) {
    console.error('[Delete Equipment Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete equipment',
      error: error.message
    });
  }
};

module.exports = {
  getEquipment,
  getEquipmentById,
  createEquipment,
  updateEquipment,
  deleteEquipment
};
