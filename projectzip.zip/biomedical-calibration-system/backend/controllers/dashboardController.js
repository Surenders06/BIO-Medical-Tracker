const Equipment = require('../models/Equipment');
const Calibration = require('../models/Calibration');
const Maintenance = require('../models/Maintenance');

/**
 * @desc    Get dashboard metrics computed from actual MongoDB data
 * @route   GET /api/dashboard/summary
 * @access  Private (Admin, Technician, Staff)
 */
const getDashboardSummary = async (req, res) => {
  try {
    const now = new Date();

    // 1. Total equipment count
    const totalEquipment = await Equipment.countDocuments();

    // 2. Equipment counts by status
    const operationalCount = await Equipment.countDocuments({ status: 'Operational' });
    const maintenanceRequiredCount = await Equipment.countDocuments({ status: 'Maintenance Required' });
    const outOfServiceCount = await Equipment.countDocuments({ status: 'Out of Service' });
    
    // Calibration Due: status is explicitly 'Calibration Due' OR nextCalibrationDate is in past/within 14 days
    const fourteenDaysAhead = new Date();
    fourteenDaysAhead.setDate(fourteenDaysAhead.getDate() + 14);

    const calibrationDueCount = await Equipment.countDocuments({
      $or: [
        { status: 'Calibration Due' },
        { nextCalibrationDate: { $lte: fourteenDaysAhead, $ne: null } }
      ]
    });

    // 3. Calibration records count
    const totalCalibrations = await Calibration.countDocuments();
    const passedCalibrations = await Calibration.countDocuments({
      result: { $in: ['Passed', 'Passed with Adjustment'] }
    });
    const attentionCalibrations = await Calibration.countDocuments({
      result: { $in: ['Failed', 'Needs Attention'] }
    });

    // 4. Maintenance count (Phase 1 Baseline)
    const totalMaintenance = await Maintenance.countDocuments();

    // 5. Recent Calibration Logs (Last 5)
    const recentCalibrations = await Calibration.find()
      .populate('equipment', 'equipmentId name category location')
      .populate('calibratedBy', 'name role')
      .sort({ calibrationDate: -1 })
      .limit(5);

    // 6. Devices with upcoming or overdue calibration
    const upcomingCalibrations = await Equipment.find({
      nextCalibrationDate: { $ne: null }
    })
      .sort({ nextCalibrationDate: 1 })
      .limit(5)
      .select('equipmentId name category location status nextCalibrationDate');

    // 7. Equipment count by category (MongoDB Aggregation)
    const categoryBreakdown = await Equipment.aggregate([
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]);

    return res.status(200).json({
      success: true,
      developmentStage: 'Approximately 50% Prototype (College Review Version)',
      timestamp: new Date(),
      metrics: {
        totalEquipment,
        statusCounts: {
          operational: operationalCount,
          calibrationDue: calibrationDueCount,
          maintenanceRequired: maintenanceRequiredCount,
          outOfService: outOfServiceCount
        },
        calibrationCounts: {
          total: totalCalibrations,
          passed: passedCalibrations,
          needsAttention: attentionCalibrations
        },
        maintenanceCounts: {
          totalWorkOrders: totalMaintenance,
          statusNote: 'Maintenance module foundational schema ready; workflow planned for Phase 2'
        },
        categoryBreakdown,
        recentCalibrations,
        upcomingCalibrations
      }
    });
  } catch (error) {
    console.error('[Dashboard Summary Error]:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to compute dashboard metrics',
      error: error.message
    });
  }
};

module.exports = {
  getDashboardSummary
};
