const mongoose = require('mongoose');

const equipmentSchema = new mongoose.Schema(
  {
    equipmentId: {
      type: String,
      required: [true, 'Equipment ID is required (e.g., BMD-ECG-101)'],
      unique: true,
      trim: true,
      uppercase: true
    },
    name: {
      type: String,
      required: [true, 'Equipment name is required'],
      trim: true
    },
    category: {
      type: String,
      required: [true, 'Equipment category is required'],
      enum: [
        'Diagnostic',
        'Life Support',
        'Monitoring',
        'Laboratory',
        'Therapeutic',
        'Surgical'
      ]
    },
    manufacturer: {
      type: String,
      required: [true, 'Manufacturer is required'],
      trim: true
    },
    model: {
      type: String,
      required: [true, 'Model name/number is required'],
      trim: true
    },
    serialNumber: {
      type: String,
      trim: true,
      default: 'N/A'
    },
    location: {
      department: {
        type: String,
        required: [true, 'Hospital department is required'],
        trim: true
      },
      roomNumber: {
        type: String,
        trim: true,
        default: 'General'
      },
      building: {
        type: String,
        trim: true,
        default: 'Main Block'
      }
    },
    purchaseDate: {
      type: Date,
      default: Date.now
    },
    purchaseCost: {
      type: Number,
      min: [0, 'Purchase cost must be a positive number'],
      default: 0
    },
    status: {
      type: String,
      enum: [
        'Operational',
        'Maintenance Required',
        'Calibration Due',
        'Out of Service'
      ],
      default: 'Operational'
    },
    calibrationFrequencyMonths: {
      type: Number,
      default: 6,
      min: [1, 'Calibration frequency must be at least 1 month']
    },
    lastCalibrationDate: {
      type: Date,
      default: null
    },
    nextCalibrationDate: {
      type: Date,
      default: null
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model('Equipment', equipmentSchema);
