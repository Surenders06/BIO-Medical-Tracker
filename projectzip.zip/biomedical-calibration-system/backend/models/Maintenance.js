const mongoose = require('mongoose');

/**
 * Maintenance Model (Phase 1 Baseline Schema)
 * 
 * DEVELOPMENT STATUS: PARTIALLY IMPLEMENTED (FOUNDATION FOR PHASE 2)
 * In the current 50% college review prototype, core CRUD is established for
 * User, Equipment, and Calibration. The maintenance workflow is architected here
 * to demonstrate database design readiness for the upcoming final phase.
 */
const maintenanceSchema = new mongoose.Schema(
  {
    workOrderId: {
      type: String,
      required: true,
      unique: true,
      trim: true
    },
    equipment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Equipment',
      required: true
    },
    maintenanceType: {
      type: String,
      enum: ['Preventive', 'Corrective', 'Emergency Breakdown'],
      default: 'Preventive'
    },
    issueDescription: {
      type: String,
      required: true,
      trim: true
    },
    reportedDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['Reported', 'Assigned', 'In Progress', 'Resolved', 'Closed'],
      default: 'Reported'
    },
    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      default: 'Medium'
    },
    actionTaken: {
      type: String,
      trim: true,
      default: 'Pending technician inspection'
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model('Maintenance', maintenanceSchema);
