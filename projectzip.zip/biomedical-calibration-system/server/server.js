const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

// Load environment variables from .env file
dotenv.config();

const app = express();

// Configure CORS for cross-origin requests
app.use(cors());

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging middleware for backend diagnostics
app.use((req, res, next) => {
  console.log(`[HTTP Request] ${req.method} ${req.url}`);
  next();
});

// Health check endpoint
// Required exact response: { "success": true, "message": "Biomedical Calibration API is running" }
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Biomedical Calibration API is running'
  });
});

// Root API information endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    project: 'Biomedical Device Calibration and Maintenance Management System',
    status: 'Backend Foundation Active',
    endpoints: {
      health: '/api/health'
    }
  });
});

// 404 Route Not Found Handler
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`
  });
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('[Unhandled Error]:', err.stack);

  // Mongoose duplicate key error (code 11000)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || 'field';
    return res.status(400).json({
      success: false,
      message: `A record with that ${field} already exists.`
    });
  }

  // Mongoose CastError (invalid ObjectId format)
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: `Invalid format for resource identifier: ${err.value}`
    });
  }

  // Mongoose ValidationError
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map((val) => val.message);
    return res.status(400).json({
      success: false,
      message: messages.join(', ')
    });
  }

  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

// Server initialization
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  // Establish MongoDB connection
  await connectDB();

  const server = app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(` Biomedical Calibration API Server Running`);
    console.log(` Port: ${PORT} | Mode: ${process.env.NODE_ENV || 'development'}`);
    console.log(` Health Endpoint: http://localhost:${PORT}/api/health`);
    console.log(`====================================================`);
  });

  return server;
};

// Start the server if file is executed directly
if (require.main === module) {
  startServer();
}

module.exports = { app, startServer };
