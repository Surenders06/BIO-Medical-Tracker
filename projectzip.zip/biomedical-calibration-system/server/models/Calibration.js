const mongoose = require('mongoose');

const parameterCheckSchema = new mongoose.Schema(
  {
    parameter: {
      type: String,
      required: [true, 'Parameter name is required'],
      trim: true
    },
    referenceValue: {
      type: String,
      required: [true, 'Reference calibration value is required'],
      trim: true
    },
    measuredValue: {
      type: String,
      required: [true, 'Measured reading value is required'],
      trim: true
    },
    status: {
      type: String,
      enum: {
        values: ['Pass', 'Fail', 'Adjusted'],
        message: '{VALUE} is not a valid parameter test status'
      },
      default: 'Pass'
    }
  },
  { _id: false }
);

const calibrationSchema = new mongoose.Schema(
  {
    calibrationId: {
      type: String,
      required: [true, 'Calibration record ID is required (e.g. CAL-2026-001)'],
      unique: true,
      trim: true,
      uppercase: true,
      index: true
    },
    equipment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Equipment',
      required: [true, 'Associated equipment reference is required'],
      index: true
    },
    calibrationDate: {
      type: Date,
      required: [true, 'Calibration date is required'],
      default: Date.now,
      index: true
    },
    nextCalibrationDate: {
      type: Date,
      required: [true, 'Next calibration due date is required'],
      index: true
    },
    calibratedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'Calibrating technician reference is required']
    },
    technicianName: {
      type: String,
      required: [true, 'Technician name is required'],
      trim: true
    },
    calibrationStandard: {
      type: String,
      required: [true, 'Calibration standard reference instrument is required'],
      trim: true
    },
    result: {
      type: String,
      required: [true, 'Calibration outcome result is required'],
      enum: {
        values: ['Passed', 'Passed with Adjustment', 'Failed', 'Needs Attention'],
        message: '{VALUE} is not a valid calibration result'
      },
      default: 'Passed',
      index: true
    },
    parametersChecked: {
      type: [parameterCheckSchema],
      default: []
    },
    remarks: {
      type: String,
      trim: true,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

// Compound index for querying calibration history of specific equipment in descending chronological order
calibrationSchema.index({ equipment: 1, calibrationDate: -1 });

module.exports = mongoose.model('Calibration', calibrationSchema);
